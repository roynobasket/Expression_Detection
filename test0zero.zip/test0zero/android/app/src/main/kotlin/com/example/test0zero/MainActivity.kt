package com.example.test0zero

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
